<?php
/**
 * Limpia templates_c. Se puede invocar directamente en el navegador.
 * 
 * $Revision: 1.2 $
 */
include('igep/limpiar_smarty_inc.php');

?>