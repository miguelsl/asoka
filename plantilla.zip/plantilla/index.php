<?php
/**
 * P�gina principal
 *
 * $Revision: 1.2 $
 */

include('igep/indice.php');

?>
