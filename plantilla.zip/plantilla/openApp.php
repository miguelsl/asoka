<?php
/**
 * P�gina inicial
 *
 * $Revision: 1.2 $
 */

include_once('igep/openApp_inc.php');

?>
