<?php
/**
 * Controlador
 *
 * $Revision: 1.2 $
 */
 include 'igep/include/gvHidraMaps.php';


	class ComponentesMap extends gvHidraMaps {
        /**
         *      constructor function
         *      @return void
         */
		function ComponentesMap () {
                
            //Llamamos al constructor del padre. Cargamos la accines gen�ricas de Igep           	
			parent::gvHidraMaps();				

			$this->_AddMapping('abrirAplicacion', 'AppMainWindow');
			$this->_AddForward('abrirAplicacion', 'gvHidraOpenApp', 'index.php?view=igep/views/aplicacion.php');
			$this->_AddForward('abrirAplicacion', 'gvHidraCloseApp', 'index.php?view=igep/views/gvHidraCloseApp.php');
			
			//.....//	
		}
	}//FIN clase 

?>