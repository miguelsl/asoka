<?php
/**
 * P�gina principal
 *
 * $Revision: 1.2 $
 */
include_once('igep/phrame_inc.php');

?>

