<?php
global $s;
$s->display('igep_ordenarTabla.tpl');
?>