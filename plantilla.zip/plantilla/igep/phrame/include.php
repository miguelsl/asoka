<?php
include('util/Object.php');
include('util/ArrayList.php');
include('util/HashMap.php');
include('util/Stack.php');
include('util/ListIterator.php');
include('ext/Xml.php');
include('Constants.php');
include('Action.php');
include('ActionController.php');
include('ActionForward.php');
include('ActionMapping.php');
//A�adida por EALEMANY
require_once 'MappingManager.php';
?>
