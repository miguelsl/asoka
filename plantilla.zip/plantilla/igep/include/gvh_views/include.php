<?php
/**
* @version
* @author Toni: <felix_ant@gva.es>
* @package	gvHIDRA
* Contiene todos los patrones gvHidra
**/

include_once 'IgepPanel.php';
include_once 'IgepPantalla.php';
$al->registerClass('IgepPanelArbol', 'igep/include/gvh_views/IgepPanelArbol.php');

?>