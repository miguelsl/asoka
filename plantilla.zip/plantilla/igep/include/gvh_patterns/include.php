<?php
/**
* @version
* @author Toni: <felix_ant@gva.es>
* @package	gvHIDRA
* Contiene todos los patrones gvHidra
**/

include_once "gvHidraForm.php";
include_once "gvHidraForm_DB.php";
$al->registerClass('gvHidraForm_dummy', 'igep/include/gvh_patterns/gvHidraForm_dummy.php');
$al->registerClass('gvHidraTreePattern', 'igep/include/gvh_patterns/gvHidraTreePattern.php');

?>
