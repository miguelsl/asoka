<?php
// Clase para la pantalla inicial
include_once('igep/custom/greenStyle/actions/CustomMainWindow.php');
include_once('igep/custom/greenStyle/types/typeNIF.php');
?>
