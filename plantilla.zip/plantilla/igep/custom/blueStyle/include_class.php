<?php
// Clase para la pantalla inicial
include_once('igep/custom/blueStyle/actions/CustomMainWindow.php');
include_once('igep/custom/blueStyle/types/typeNIF.php');
?>
