<?php
// Clase para la pantalla inicial
include_once('igep/custom/default/actions/CustomMainWindow.php');
include_once('igep/custom/default/types/typeNIF.php');
?>
